// Función para calcular el factorial de un número
int factorial(int n) {
    if (n <= 1)
        return 1;
    else
        return n * factorial(n - 1);
}

int main() {
    int a = 15111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111115;
    return 0;
}
